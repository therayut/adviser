-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jun 21, 2013 at 01:49 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `adviser`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `appointmentdoc`
-- 

CREATE TABLE `appointmentdoc` (
  `appointmentDocID` int(5) NOT NULL auto_increment,
  `FacultyID` varchar(2) NOT NULL,
  `numberDoc` varchar(10) NOT NULL,
  `title` text NOT NULL,
  `year` char(4) NOT NULL,
  `detail` text NOT NULL,
  `dateDoc` date NOT NULL,
  `userID` int(11) NOT NULL,
  PRIMARY KEY  (`appointmentDocID`),
  KEY `FacultyID` (`FacultyID`,`userID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `appointmentdoc`
-- 

INSERT INTO `appointmentdoc` VALUES (5, '04', 'ss', 'ss', 'ss', '', '0000-00-00', 2);
INSERT INTO `appointmentdoc` VALUES (6, '04', 'ff', 'ff', 'ff', '', '0000-00-00', 2);

-- --------------------------------------------------------

-- 
-- Table structure for table `appointmentfilepdf`
-- 

CREATE TABLE `appointmentfilepdf` (
  `FilesID` int(11) NOT NULL auto_increment,
  `FilesName` varchar(255) NOT NULL,
  PRIMARY KEY  (`FilesID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `appointmentfilepdf`
-- 

INSERT INTO `appointmentfilepdf` VALUES (1, 'ch 3 cpu1111.pptx');
INSERT INTO `appointmentfilepdf` VALUES (2, 'ที่มา.txt');
INSERT INTO `appointmentfilepdf` VALUES (3, 'เตรียมสอบ.doc');
INSERT INTO `appointmentfilepdf` VALUES (4, 'การจัดการหน่วยความจำหลัก.docx');
INSERT INTO `appointmentfilepdf` VALUES (5, 'FW001.pdf');

-- --------------------------------------------------------

-- 
-- Table structure for table `calendarmeet`
-- 

CREATE TABLE `calendarmeet` (
  `calendarID` int(4) NOT NULL auto_increment,
  `userID` int(11) NOT NULL,
  `FacultyID` varchar(2) NOT NULL,
  `dateCalendar` date NOT NULL,
  `year` char(4) NOT NULL,
  `detail` text NOT NULL,
  PRIMARY KEY  (`calendarID`),
  KEY `userID` (`userID`,`FacultyID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `calendarmeet`
-- 

INSERT INTO `calendarmeet` VALUES (6, 2, '04', '2556-12-12', '2556', 'ทดสอบ');

-- --------------------------------------------------------

-- 
-- Table structure for table `dating`
-- 

CREATE TABLE `dating` (
  `datingID` int(11) NOT NULL,
  `userSender` int(11) NOT NULL,
  `userRecipient` int(11) NOT NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`datingID`,`userSender`,`userRecipient`),
  KEY `userSender` (`userSender`),
  KEY `userRecipient` (`userRecipient`),
  KEY `datingID` (`datingID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `dating`
-- 

INSERT INTO `dating` VALUES (1, 5, 1, '2013-06-03 12:16:46');
INSERT INTO `dating` VALUES (1, 5, 2, '2013-06-03 12:16:46');
INSERT INTO `dating` VALUES (1, 5, 3, '2013-06-03 12:16:46');
INSERT INTO `dating` VALUES (6, 5, 1, '2013-06-03 12:25:43');
INSERT INTO `dating` VALUES (6, 5, 2, '2013-06-03 12:25:44');
INSERT INTO `dating` VALUES (7, 7, 5, '2013-06-03 17:38:16');
INSERT INTO `dating` VALUES (8, 7, 3, '2013-06-03 17:38:52');
INSERT INTO `dating` VALUES (8, 7, 5, '2013-06-03 17:38:52');
INSERT INTO `dating` VALUES (9, 5, 3, '2013-06-03 22:45:55');
INSERT INTO `dating` VALUES (9, 5, 7, '2013-06-03 22:45:55');
INSERT INTO `dating` VALUES (10, 5, 3, '2013-06-03 22:55:13');
INSERT INTO `dating` VALUES (10, 5, 7, '2013-06-03 22:55:13');
INSERT INTO `dating` VALUES (11, 3, 5, '2013-06-03 23:01:38');
INSERT INTO `dating` VALUES (11, 3, 7, '2013-06-03 23:01:38');
INSERT INTO `dating` VALUES (12, 3, 5, '2013-06-03 23:55:34');
INSERT INTO `dating` VALUES (12, 3, 7, '2013-06-03 23:55:34');

-- --------------------------------------------------------

-- 
-- Table structure for table `department`
-- 

CREATE TABLE `department` (
  `DepartmentID` varchar(4) NOT NULL,
  `DepartmentName` varchar(30) NOT NULL,
  `FacultyID` varchar(2) NOT NULL,
  PRIMARY KEY  (`DepartmentID`),
  KEY `FacultyID` (`FacultyID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `department`
-- 

INSERT INTO `department` VALUES ('0403', 'คณิตศาสตร์และคอมพิวเตอร์', '04');
INSERT INTO `department` VALUES ('0402', 'วิทยาศาสตร์สุขภาพ', '04');
INSERT INTO `department` VALUES ('0401', 'วิทยาศาสตร์', '04');
INSERT INTO `department` VALUES ('0404', 'สิงแวดล้อมและพลังงาน', '04');
INSERT INTO `department` VALUES ('0301', 'ภาษาไทย', '03');

-- --------------------------------------------------------

-- 
-- Table structure for table `detaildating`
-- 

CREATE TABLE `detaildating` (
  `datingID` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `detail` text NOT NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`datingID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- 
-- Dumping data for table `detaildating`
-- 

INSERT INTO `detaildating` VALUES (1, 'aa', 'aa', '2013-06-03 12:16:46');
INSERT INTO `detaildating` VALUES (5, 'aa', 'aa', '2013-06-03 12:24:57');
INSERT INTO `detaildating` VALUES (6, 'aa', 'aa', '2013-06-03 12:25:43');
INSERT INTO `detaildating` VALUES (7, 'ทดสอบ', 'ทดสอบระบบ', '2013-06-03 17:38:16');
INSERT INTO `detaildating` VALUES (8, 'ทดสอบ2', 'ทดสอบระบบ2', '2013-06-03 17:38:52');
INSERT INTO `detaildating` VALUES (9, 'ทดสอบ3', 'ทดสอบระบบ3', '2013-06-03 22:45:55');
INSERT INTO `detaildating` VALUES (10, 'ทดสอบ4', 'ทดสอบระบบ4', '2013-06-03 22:55:13');
INSERT INTO `detaildating` VALUES (11, 'เข้าเรียน', 'วันที่15', '2013-06-03 23:01:38');
INSERT INTO `detaildating` VALUES (12, 'ทดสอบส่ง', 'ทดสอบ tinyMCE', '2013-06-05 12:04:34');

-- --------------------------------------------------------

-- 
-- Table structure for table `faculty`
-- 

CREATE TABLE `faculty` (
  `FacultyID` varchar(2) NOT NULL,
  `FacultyName` varchar(30) NOT NULL,
  PRIMARY KEY  (`FacultyID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `faculty`
-- 

INSERT INTO `faculty` VALUES ('03', 'ครุศาสตร์');
INSERT INTO `faculty` VALUES ('04', 'วิทยาศาสตร์');
INSERT INTO `faculty` VALUES ('01', 'วิทยาการจัดการ');
INSERT INTO `faculty` VALUES ('02', 'วิทยาลัยนานาชาติ');

-- --------------------------------------------------------

-- 
-- Table structure for table `form`
-- 

CREATE TABLE `form` (
  `formID` int(11) NOT NULL auto_increment,
  `formName` varchar(30) NOT NULL,
  `file` text NOT NULL,
  PRIMARY KEY  (`formID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `form`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `fw001`
-- 

CREATE TABLE `fw001` (
  `formID` int(4) NOT NULL auto_increment,
  `field_1` varchar(6) character set tis620 NOT NULL,
  `field_2` varchar(6) character set tis620 NOT NULL,
  `field_3` date NOT NULL,
  `field_4` varchar(30) NOT NULL,
  `field_5` varchar(30) character set tis620 NOT NULL,
  `field_6` varchar(60) character set tis620 NOT NULL,
  `field_7` int(3) NOT NULL,
  `field_8` int(3) NOT NULL,
  `field_9_1` varchar(255) character set tis620 NOT NULL,
  `field_9_2` varchar(255) character set tis620 NOT NULL,
  `field_9_3` varchar(255) NOT NULL,
  `field_9_4` varchar(255) character set tis620 NOT NULL,
  `field_9_5` varchar(255) character set tis620 NOT NULL,
  `field_10_1` varchar(255) character set tis620 NOT NULL,
  `field_10_2` varchar(255) character set tis620 NOT NULL,
  `field_10_3` varchar(255) character set tis620 NOT NULL,
  `field_10_4` varchar(255) character set tis620 NOT NULL,
  `field_11_1` varchar(255) character set tis620 NOT NULL,
  `field_11_2` varchar(255) character set tis620 NOT NULL,
  `field_11_3` varchar(255) character set tis620 NOT NULL,
  `field_11_4` varchar(255) character set tis620 NOT NULL,
  `field_12` varchar(60) character set tis620 NOT NULL,
  `field_13` varchar(60) character set tis620 NOT NULL,
  `field_14` varchar(60) character set tis620 NOT NULL,
  PRIMARY KEY  (`formID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `fw001`
-- 

INSERT INTO `fw001` VALUES (1, '1', '2', '0000-00-00', 'กฤษณ์', 'ชัยวัณณคุปต์', 'วิทยาการคอมพิวเตอร์', 30, 28, '- การลงทะเบียนเรียนภาคเรียนที่ 1/52', '- ชี้แจงกิจกรรมไหว้ครู ของสาขาิชาฯ', '- ปัญหาเกี่ยวกับผลการเรียน', '', '', '- นักศึกษามีเกณฑ์ผลการเรียนต่ำ', '', '', '', '- ได้ทำการพูดคุยให้คำปรึกษาแก่นักศึกษาที่มีผลการเรียนต่ำ และเสนอแนะแนวทางการแก้ปัญหา', '', '', '', '    อ.กฤษณ์  ชัยวัณณคุปต์', '', '');
INSERT INTO `fw001` VALUES (2, '1', '4', '0000-00-00', 'อ.จำรูญ', 'จันทรกุญชร', 'วิทยาการคอมพิวเตอร์', 50, 45, '- การลงทะเบียน', '- การเข้าเรียน', '', '', '', '- ผลการเรียน', '', '', '', '- ได้ให้ข้อเสนอแนะ', '', '', '', '       จำรูญ    จันทรกุญชร', '  12      12       52', '           สมชาย   สายช่า');
INSERT INTO `fw001` VALUES (3, '1/56', '2', '2012-12-12', 'กฤษณ์', 'ชัยวัณณคุปต์', 'วิทยาการคอมพิวเตอร์', 30, 28, '- การลงทะเบียนเรียนภาคเรียนที่ 1/52', '- ชี้แจงกิจกรรมไหว้ครู ของสาขาิชาฯ', '- ปัญหาเกี่ยวกับผลการเรียน', '', '', '- นักศึกษามีเกณฑ์ผลการเรียนต่ำ', '', '', '', '- ได้ทำการพูดคุยให้คำปรึกษาแก่นักศึกษาที่มีผลการเรียนต่ำ และเสนอแนะแนวทางการแก้ปัญหา', '', '', '', '    อ.กฤษณ์  ชัยวัณณคุปต์', '  12     12       2556', '      ผสดร.สำราญ  รื่นมื่น');

-- --------------------------------------------------------

-- 
-- Table structure for table `major`
-- 

CREATE TABLE `major` (
  `MajorID` varchar(7) NOT NULL,
  `MajorName` varchar(30) NOT NULL,
  `DepartmentID` varchar(4) NOT NULL,
  `FacultyID` varchar(7) NOT NULL,
  PRIMARY KEY  (`MajorID`),
  KEY `DepartmentID` (`DepartmentID`),
  KEY `FacultyID` (`FacultyID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `major`
-- 

INSERT INTO `major` VALUES ('040203', 'วิทยาศาสตร์การกีฬา', '0402', '04');
INSERT INTO `major` VALUES ('040202', 'อาหารและโภชนาการ', '0402', '04');
INSERT INTO `major` VALUES ('040201', 'สาธารณสุขชุมชน', '0402', '04');
INSERT INTO `major` VALUES ('040103', 'ชีววิทยา', '0401', '04');
INSERT INTO `major` VALUES ('040102', 'เคมี', '0401', '04');
INSERT INTO `major` VALUES ('040101', 'ฟิสิกส์', '0401', '04');
INSERT INTO `major` VALUES ('040301', 'คณิตศาสตร์', '0403', '04');
INSERT INTO `major` VALUES ('040302', 'วิทยาการคอมพิวเตอร์', '0403', '04');
INSERT INTO `major` VALUES ('040303', 'เทคโนโลยีสารสนเทศ', '0403', '04');
INSERT INTO `major` VALUES ('040401', 'วิทยาศาสตร์สิ่งแวดล้อม', '0404', '04');
INSERT INTO `major` VALUES ('040402', 'สิ่งแวดล้อมศึกษา', '0404', '04');
INSERT INTO `major` VALUES ('040403', 'พลังงานและสิ่งแวดล้อม', '0404', '04');

-- --------------------------------------------------------

-- 
-- Table structure for table `new`
-- 

CREATE TABLE `new` (
  `newID` int(6) NOT NULL auto_increment,
  `userID` int(11) NOT NULL,
  `dateNew` date NOT NULL,
  `title` text NOT NULL,
  `detail` text NOT NULL,
  `FacultyID` varchar(2) NOT NULL,
  PRIMARY KEY  (`newID`),
  KEY `userID` (`userID`),
  KEY `FacultyID` (`FacultyID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `new`
-- 

INSERT INTO `new` VALUES (1, 3, '2556-12-12', 'ภาพแบบร่างสุดท้ายของ iPhone mini', 'หลังจากที่เราได้นำเสนอภาพแบบร่าง iPhone mini ไปเมื่อก่อนหน้านี้ เราได้รับแจ้งมาว่าภาพก่อนหน้าเป็นโครงสร้างแบบ Draft คร่าวๆ ซึ่งมีการจัดทำขึ้นมาเพื่อจำลองหน้าตาแบบไม่สนใจสเกลเฉยๆ ซึ่งทำให้อาจจะมีตำแหน่งของปุ่มต่างๆ และขนาดตัวเครื่องแปลกตาลงไปบ้าง', '04');
INSERT INTO `new` VALUES (2, 3, '2556-02-03', 'เตรียมพบกับ Firefox โฉมใหม่ (เร็วๆ นี้?)', 'Mozilla กำลังทำโครงการ Australis ซึ่งเป็นโครงการออกแบบเว็บเบราว์เซอร์ใหม่สำหรับอนาคต เพื่อให้สอดคล้องกับการใช้งานของผู้ใช้  Mozilla ให้เหตุผลว่าทุกวันนี้การใช้งานเว็บเบราว์เซอร์มาไกลเกินกว่าการท่องเว็บแต่ เพียงอย่างเดียวแล้ว เพราะในปัจจุบันมีทั้งการใช้เว็บแอพ, ทั้งการเชื่อมโยงกับเครือข่ายสังคมต่างๆ และการใช้งานเพื่อการอื่นอีกมากมาย ซึ่งนั่นทำให้เว็บเบราว์เซอร์ได้รับการปรับปรุงด้านฟังก์ชันและฟีเจอร์ต่างๆ เป็นอันมาก และสมควรได้รับการออกแบบ', '04');

-- --------------------------------------------------------

-- 
-- Table structure for table `performancereport`
-- 

CREATE TABLE `performancereport` (
  `perReportID` varchar(5) NOT NULL,
  `userID` int(11) NOT NULL,
  `term` varchar(2) NOT NULL,
  `date` date NOT NULL,
  `title` text NOT NULL,
  `problem` text NOT NULL,
  `suggestion` text NOT NULL,
  PRIMARY KEY  (`perReportID`),
  KEY `userID` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `performancereport`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `recordmeet`
-- 

CREATE TABLE `recordmeet` (
  `recordMeetID` int(5) NOT NULL auto_increment,
  `userID` int(11) NOT NULL,
  `title` text NOT NULL,
  `problem` text NOT NULL,
  `suggestion` text NOT NULL,
  `student` text NOT NULL,
  `term` varchar(2) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`recordMeetID`),
  KEY `teacherID` (`userID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `recordmeet`
-- 

INSERT INTO `recordmeet` VALUES (1, 3, '55555', '4', '4', '4', '2', '2556-12-12');
INSERT INTO `recordmeet` VALUES (2, 3, '5', '5', '5', '5', '5', '2556-12-12');

-- --------------------------------------------------------

-- 
-- Table structure for table `studentgroup`
-- 

CREATE TABLE `studentgroup` (
  `groupID` int(4) NOT NULL auto_increment,
  `groupName` varchar(100) NOT NULL,
  `year` char(4) NOT NULL,
  `studentInGroup` text NOT NULL,
  `teacherInGroup` text NOT NULL,
  `FacultyID` varchar(2) NOT NULL,
  `DepartmentID` varchar(4) NOT NULL,
  `MajorID` varchar(7) NOT NULL,
  PRIMARY KEY  (`groupID`),
  KEY `FacultyID` (`FacultyID`,`DepartmentID`,`MajorID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `studentgroup`
-- 

INSERT INTO `studentgroup` VALUES (3, 'คณิต', '2555', '20', '1', '04', '0403', '040301');
INSERT INTO `studentgroup` VALUES (4, 'คอมปี2', '2556', '20', '2', '04', '0403', '040301');
INSERT INTO `studentgroup` VALUES (5, 'aa', '2556', '46', '46', '04', '0403', '040301');

-- --------------------------------------------------------

-- 
-- Table structure for table `sumofoperationsteacher`
-- 

CREATE TABLE `sumofoperationsteacher` (
  `SOTID` int(5) NOT NULL auto_increment,
  `userID` varchar(3) NOT NULL,
  `FacultyID` varchar(2) NOT NULL,
  `title` text NOT NULL,
  `problem` text NOT NULL,
  `suggestion` text NOT NULL,
  `term` char(2) NOT NULL,
  `year` char(4) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`SOTID`),
  KEY `staffID` (`userID`,`FacultyID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `sumofoperationsteacher`
-- 

INSERT INTO `sumofoperationsteacher` VALUES (2, '2', '04', 'สรุปงานอาจารย์ที่ปรึกษา', 'การเข้าเรียน', 'เช็คชื่อตัดคะแนน', '2', '2556', '2556-12-12');

-- --------------------------------------------------------

-- 
-- Table structure for table `user`
-- 

CREATE TABLE `user` (
  `userID` int(11) NOT NULL auto_increment,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `userTypeID` char(1) NOT NULL,
  `FacultyID` varchar(2) NOT NULL,
  `DepartmentID` varchar(4) NOT NULL,
  `MajorID` varchar(7) NOT NULL,
  `name` varchar(60) NOT NULL,
  `surname` varchar(60) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `SID` varchar(32) NOT NULL,
  `Active` enum('NO','YES') NOT NULL,
  `identificationID` char(13) NOT NULL,
  `img` varchar(100) NOT NULL,
  PRIMARY KEY  (`userID`),
  KEY `userTypeID` (`userTypeID`,`FacultyID`,`DepartmentID`,`MajorID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` VALUES (1, 'admin', '1234', '1', '04', '0401', '040101', 'ธีรยุทธ', 'ใจธรรม', '50/1', '08-4814-7935', 'skyblackyut@gmail.com', '', 'YES', '1650300050227', 'jquery12-cheatsheet-1280-002.png');
INSERT INTO `user` VALUES (2, 'staff', '1234', '2', '04', '0401', '040101', 'สมชัย', 'ขาวมาก', 'ข', '08-4814-7935', 'skyblackyut@gmail.com', '', 'YES', '1650300050227', 'teacher.png');
INSERT INTO `user` VALUES (3, 'teacher', '1234', '3', '04', '0401', '040101', 'สมหมาย', 'หลายใจ', 'อุตรดิตถ์', '0810364619', 'skyblackyut@gmail.com', '', 'YES', '1650300050227', 'Teachers-icon.png');
INSERT INTO `user` VALUES (5, 'student1', '1234', '4', '04', '0401', '040101', 'ธีรยุทธ', 'ใจธรรม', '50/1 หมุ่10', '0848147935', 'skyblackyut@gmail.com', '', 'YES', '1650300050227', 'group_buy.png');
INSERT INTO `user` VALUES (7, 'student2', '1234', '4', '04', '0401', '040101', 'นาราย', 'ใจมา', '50/1', '0848147935', 'skyblackyut@gmail.com', '0208eb48fd414e9b5dbe4af086fadaf4', 'YES', '1650300050227', '');
INSERT INTO `user` VALUES (8, '4', '4', '2', '4', '4', '4', '4', '4', '4', '4', 'skyblackyut@gmail.com', 'aea430351f04c32f8c11d6824552fc78', 'NO', '4', '');
INSERT INTO `user` VALUES (18, 'test', '1234', '2', '03', '0301', '030101', '', '', '', '', 'skyblackyut@gmail.com', '0a72df8db98941baf0480adec70cc3d2', 'YES', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `usertype`
-- 

CREATE TABLE `usertype` (
  `UserTypeID` char(1) NOT NULL,
  `UserTypeName` varchar(30) NOT NULL,
  PRIMARY KEY  (`UserTypeID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `usertype`
-- 

INSERT INTO `usertype` VALUES ('1', 'ผู้ดูแลระบบ');
INSERT INTO `usertype` VALUES ('2', 'เจ้าหน้าที่');
INSERT INTO `usertype` VALUES ('3', 'อาจารย์');
INSERT INTO `usertype` VALUES ('4', 'นักศึกษา');

-- 
-- Constraints for dumped tables
-- 

-- 
-- Constraints for table `dating`
-- 
ALTER TABLE `dating`
  ADD CONSTRAINT `dating_ibfk_4` FOREIGN KEY (`datingID`) REFERENCES `detaildating` (`datingID`),
  ADD CONSTRAINT `dating_ibfk_5` FOREIGN KEY (`userSender`) REFERENCES `user` (`userID`),
  ADD CONSTRAINT `dating_ibfk_6` FOREIGN KEY (`userRecipient`) REFERENCES `user` (`userID`);
